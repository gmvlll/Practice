﻿using Practice.Algorithms;
using Practice.Models;
using Practice.Services;

namespace Practice.Services
{
    public class DriverSelectionService
    {
        private readonly Dictionary<string, Driver> _drivers = new();
        private readonly List<IDriverService> _algorithms;

        public int N { get; }
        public int M { get; }

        public DriverSelectionService(int n, int m)
        {
            N = n;
            M = m;
            _algorithms = new List<IDriverService>
            {
                new BruteForceDriverService(_drivers),
                new GridPartitionDriverService(_drivers, n, m),
                new PriorityQueueDriverService(_drivers)
            };
        }

        public void AddOrUpdateDriver(Driver driver)
        {
            if (driver.X < 0 || driver.X >= N || driver.Y < 0 || driver.Y >= M)
                throw new ArgumentException("Driver coordinates are out of bounds");

            _drivers[driver.Id] = driver;

            foreach (var algorithm in _algorithms)
            {
                algorithm.AddOrUpdateDriver(driver);
            }
        }

        public void RemoveDriver(string driverId)
        {
            if (_drivers.Remove(driverId))
            {
                foreach (var algorithm in _algorithms)
                {
                    algorithm.RemoveDriver(driverId);
                }
            }
        }

        public List<DriverDistance> FindNearestDrivers(int algorithmIndex, Order order, int count = 5)
        {
            if (algorithmIndex < 0 || algorithmIndex >= _algorithms.Count)
                throw new ArgumentException("Invalid algorithm index");

            return _algorithms[algorithmIndex].FindNearestDrivers(order, count);
        }

        public List<IDriverService> GetAlgorithms() => _algorithms;
    }
}