﻿using Practice.Models;

namespace Practice.Services
{
    public interface IDriverService
    {
        void AddOrUpdateDriver(Driver driver);
        void RemoveDriver(string driverId);
        List<DriverDistance> FindNearestDrivers(Order order, int count = 5);
        string AlgorithmName { get; }
    }
}