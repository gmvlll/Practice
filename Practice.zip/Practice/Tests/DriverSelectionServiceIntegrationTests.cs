﻿using NUnit.Framework;
using Practice.Models;
using Practice.Services;

namespace Practice.Tests
{
    [TestFixture]
    public class DriverSelectionServiceIntegrationTests
    {
        private DriverSelectionService _service = null!;

        [SetUp]
        public void Setup()
        {
            _service = new DriverSelectionService(100, 100);
        }

        [Test]
        public void AllAlgorithms_ShouldReturnSameResultsForSameInput()
        {
            // Arrange
            var drivers = new[]
            {
                new Driver("d1", 10, 20),
                new Driver("d2", 30, 40),
                new Driver("d3", 50, 60),
                new Driver("d4", 70, 80),
                new Driver("d5", 90, 10)
            };

            foreach (var driver in drivers)
            {
                _service.AddOrUpdateDriver(driver);
            }

            var order = new Order(40, 45);
            var algorithms = _service.GetAlgorithms();

            // Act & Assert
            var results = new List<List<DriverDistance>>();
            foreach (var algorithm in algorithms)
            {
                var result = algorithm.FindNearestDrivers(order, 3);
                results.Add(result);

                // Проверяем, что все алгоритмы возвращают правильное количество
                Assert.That(result, Has.Count.EqualTo(3));
            }

            // Проверяем, что все алгоритмы возвращают одинаковых водителей (порядок может отличаться)
            var driverIds = results.Select(r => string.Join(",", r.Select(x => x.Driver.Id).OrderBy(id => id))).Distinct();
            Assert.That(driverIds.Count(), Is.EqualTo(1));
        }

        [Test]
        public void AddOrUpdateDriver_ShouldUpdateAllAlgorithms()
        {
            // Arrange
            var driver = new Driver("d1", 50, 50);
            _service.AddOrUpdateDriver(driver);
            var algorithms = _service.GetAlgorithms();
            var order = new Order(50, 50);

            // Act & Assert
            foreach (var algorithm in algorithms)
            {
                var result = algorithm.FindNearestDrivers(order, 1);
                Assert.That(result[0].Driver.Id, Is.EqualTo("d1"));
            }

            // Обновляем координаты
            var updatedDriver = new Driver("d1", 60, 60);
            _service.AddOrUpdateDriver(updatedDriver);

            // Проверяем обновление
            foreach (var algorithm in algorithms)
            {
                var result = algorithm.FindNearestDrivers(new Order(60, 60), 1);
                Assert.That(result[0].Driver.Id, Is.EqualTo("d1"));
            }
        }

        [Test]
        public void RemoveDriver_ShouldRemoveFromAllAlgorithms()
        {
            // Arrange
            var driver = new Driver("d1", 50, 50);
            _service.AddOrUpdateDriver(driver);
            var algorithms = _service.GetAlgorithms();

            // Act
            _service.RemoveDriver("d1");

            // Assert
            foreach (var algorithm in algorithms)
            {
                var result = algorithm.FindNearestDrivers(new Order(50, 50), 1);
                if (result.Count > 0)
                {
                    Assert.That(result[0].Driver.Id, Is.Not.EqualTo("d1"));
                }
            }
        }

        [Test]
        public void Service_ShouldThrowWhenDriverCoordinatesOutOfBounds()
        {
            // Arrange
            var invalidDriver = new Driver("d1", 150, 150);

            // Act & Assert
            Assert.Throws<ArgumentException>(() => _service.AddOrUpdateDriver(invalidDriver));
        }
    }
}