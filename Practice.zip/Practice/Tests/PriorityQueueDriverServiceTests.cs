﻿using NUnit.Framework;
using Practice.Algorithms;
using Practice.Models;
using Practice.Tests;

namespace Practice.Tests
{
    [TestFixture]
    public class PriorityQueueDriverServiceTests : BaseDriverTest
    {
        private PriorityQueueDriverService _service = null!;
        private Dictionary<string, Driver> _drivers = null!;

        [SetUp]
        public void Setup()
        {
            _drivers = CreateTestDrivers();
            _service = new PriorityQueueDriverService(_drivers);
        }

        [Test]
        public void FindNearestDrivers_ShouldReturnCorrectNumberOfDrivers()
        {
            // Arrange
            var order = new Order(40, 45);

            // Act
            var result = _service.FindNearestDrivers(order, 3);

            // Assert
            Assert.That(result, Has.Count.EqualTo(3));
        }

        [Test]
        public void FindNearestDrivers_ShouldReturnDriversOrderedByDistance()
        {
            // Arrange
            var order = new Order(40, 45);

            // Act
            var result = _service.FindNearestDrivers(order, 5);

            // Assert
            AssertDriversOrderedByDistance(result);
        }

        [Test]
        public void FindNearestDrivers_ShouldReturnSameResultsAsBruteForce()
        {
            // Arrange
            var bruteForceService = new BruteForceDriverService(_drivers);
            var order = new Order(40, 45);

            // Act
            var queueResult = _service.FindNearestDrivers(order, 5);
            var bruteForceResult = bruteForceService.FindNearestDrivers(order, 5);

            // Assert
            Assert.That(queueResult.Count, Is.EqualTo(bruteForceResult.Count));
            for (int i = 0; i < queueResult.Count; i++)
            {
                Assert.That(queueResult[i].Driver.Id, Is.EqualTo(bruteForceResult[i].Driver.Id));
                Assert.That(queueResult[i].Distance, Is.EqualTo(bruteForceResult[i].Distance).Within(0.001));
            }
        }

        [Test]
        public void FindNearestDrivers_WithEmptyDrivers_ShouldReturnEmptyList()
        {
            // Arrange
            var emptyDrivers = new Dictionary<string, Driver>();
            var emptyService = new PriorityQueueDriverService(emptyDrivers);
            var order = new Order(40, 45);

            // Act
            var result = emptyService.FindNearestDrivers(order, 5);

            // Assert
            Assert.That(result, Is.Empty);
        }

        [Test]
        public void FindNearestDrivers_WhenRequestingMoreThanAvailable_ShouldReturnAll()
        {
            // Arrange
            var order = new Order(40, 45);

            // Act
            var result = _service.FindNearestDrivers(order, 20);

            // Assert
            Assert.That(result, Has.Count.EqualTo(10));
        }

        [Test]
        public void AddOrUpdateDriver_ShouldNotThrowException()
        {
            // Arrange
            var newDriver = new Driver("d11", 60, 70);

            // Act & Assert
            Assert.DoesNotThrow(() => _service.AddOrUpdateDriver(newDriver));
        }

        [Test]
        public void RemoveDriver_ShouldNotThrowException()
        {
            // Act & Assert
            Assert.DoesNotThrow(() => _service.RemoveDriver("d1"));
        }
    }
}