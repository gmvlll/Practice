﻿using NUnit.Framework;
using Practice.Algorithms;
using Practice.Models;
using Practice.Tests;

namespace Practice.Tests
{
    [TestFixture]
    public class GridPartitionDriverServiceTests : BaseDriverTest
    {
        private GridPartitionDriverService _service = null!;
        private Dictionary<string, Driver> _drivers = null!;

        [SetUp]
        public void Setup()
        {
            _drivers = CreateTestDrivers();
            _service = new GridPartitionDriverService(_drivers, 100, 100, 10);
        }

        [Test]
        public void FindNearestDrivers_ShouldReturnCorrectNumberOfDrivers()
        {
            // Arrange
            var order = new Order(40, 45);

            // Act
            var result = _service.FindNearestDrivers(order, 3);

            // Assert
            Assert.That(result, Has.Count.EqualTo(3));
        }

        [Test]
        public void FindNearestDrivers_ShouldReturnDriversOrderedByDistance()
        {
            // Arrange
            var order = new Order(40, 45);

            // Act
            var result = _service.FindNearestDrivers(order, 5);

            // Assert
            AssertDriversOrderedByDistance(result);
        }

        [Test]
        public void FindNearestDrivers_ShouldReturnSameResultsAsBruteForce()
        {
            // Arrange
            var bruteForceService = new BruteForceDriverService(_drivers);
            var order = new Order(40, 45);

            // Act
            var gridResult = _service.FindNearestDrivers(order, 5);
            var bruteForceResult = bruteForceService.FindNearestDrivers(order, 5);

            // Assert
            Assert.That(gridResult.Count, Is.EqualTo(bruteForceResult.Count));
            for (int i = 0; i < gridResult.Count; i++)
            {
                Assert.That(gridResult[i].Driver.Id, Is.EqualTo(bruteForceResult[i].Driver.Id));
                Assert.That(gridResult[i].Distance, Is.EqualTo(bruteForceResult[i].Distance).Within(0.001));
            }
        }

        [Test]
        public void AddOrUpdateDriver_ShouldAddDriverToGrid()
        {
            // Arrange
            var newDriver = new Driver("d11", 55, 65);

            // Act
            _service.AddOrUpdateDriver(newDriver);
            var result = _service.FindNearestDrivers(new Order(55, 65), 1);

            // Assert
            Assert.That(result[0].Driver.Id, Is.EqualTo("d11"));
        }

        [Test]
        public void RemoveDriver_ShouldRemoveDriverFromGrid()
        {
            // Arrange
            var driverToRemove = _drivers["d1"];

            // Act
            _service.RemoveDriver("d1");
            var result = _service.FindNearestDrivers(new Order(driverToRemove.X, driverToRemove.Y), 10);

            // Assert
            Assert.That(result.Any(d => d.Driver.Id == "d1"), Is.False);
        }

        [Test]
        public void FindNearestDrivers_WithDriversInDifferentCells_ShouldFindCorrectly()
        {
            // Arrange
            var sparseDrivers = new Dictionary<string, Driver>
            {
                ["d1"] = new Driver("d1", 5, 5),    // Ячейка (0,0)
                ["d2"] = new Driver("d2", 95, 95),  // Ячейка (9,9)
                ["d3"] = new Driver("d3", 50, 50)   // Ячейка (5,5)
            };
            var sparseService = new GridPartitionDriverService(sparseDrivers, 100, 100, 10);
            var order = new Order(50, 50);

            // Act
            var result = sparseService.FindNearestDrivers(order, 3);

            // Assert
            Assert.That(result[0].Driver.Id, Is.EqualTo("d3")); // Самый близкий
            Assert.That(result, Has.Count.EqualTo(3));
        }
    }
}