﻿using NUnit.Framework;
using Practice.Algorithms;
using Practice.Models;
using Practice.Tests;

namespace Practice.Tests
{
    [TestFixture]
    public class BruteForceDriverServiceTests : BaseDriverTest
    {
        private BruteForceDriverService _service = null!;
        private Dictionary<string, Driver> _drivers = null!;

        [SetUp]
        public void Setup()
        {
            _drivers = CreateTestDrivers();
            _service = new BruteForceDriverService(_drivers);
        }

        [Test]
        public void FindNearestDrivers_ShouldReturnCorrectNumberOfDrivers()
        {
            // Arrange
            var order = new Order(40, 45);

            // Act
            var result = _service.FindNearestDrivers(order, 3);

            // Assert
            Assert.That(result, Has.Count.EqualTo(3));
        }

        [Test]
        public void FindNearestDrivers_ShouldReturnAllDriversWhenCountExceedsAvailable()
        {
            // Arrange
            var order = new Order(40, 45);

            // Act
            var result = _service.FindNearestDrivers(order, 20);

            // Assert
            Assert.That(result, Has.Count.EqualTo(10));
        }

        [Test]
        public void FindNearestDrivers_ShouldReturnDriversOrderedByDistance()
        {
            // Arrange
            var order = new Order(40, 45);

            // Act
            var result = _service.FindNearestDrivers(order, 5);

            // Assert
            AssertDriversOrderedByDistance(result);
        }

        [Test]
        public void FindNearestDrivers_ShouldReturnCorrectNearestDriver()
        {
            // Arrange
            var order = new Order(40, 45);
            var expectedNearest = _drivers["d6"]; // (25, 35) - ближайший к (40, 45)

            // Act
            var result = _service.FindNearestDrivers(order, 1);

            // Assert
            Assert.That(result[0].Driver.Id, Is.EqualTo(expectedNearest.Id));
        }

        [Test]
        public void FindNearestDrivers_WithEmptyDrivers_ShouldReturnEmptyList()
        {
            // Arrange
            var emptyDrivers = new Dictionary<string, Driver>();
            var emptyService = new BruteForceDriverService(emptyDrivers);
            var order = new Order(40, 45);

            // Act
            var result = emptyService.FindNearestDrivers(order, 5);

            // Assert
            Assert.That(result, Is.Empty);
        }

        [Test]
        public void AddOrUpdateDriver_ShouldNotThrowException()
        {
            // Arrange
            var newDriver = new Driver("d11", 60, 70);

            // Act & Assert
            Assert.DoesNotThrow(() => _service.AddOrUpdateDriver(newDriver));
        }

        [Test]
        public void RemoveDriver_ShouldNotThrowException()
        {
            // Act & Assert
            Assert.DoesNotThrow(() => _service.RemoveDriver("d1"));
        }
    }
}