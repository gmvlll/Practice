﻿using Practice.Models;
using Practice.Services;
using NUnit.Framework;

namespace Practice.Tests
{
    public abstract class BaseDriverTest
    {
        protected Dictionary<string, Driver> CreateTestDrivers()
        {
            return new Dictionary<string, Driver>
            {
                ["d1"] = new Driver("d1", 10, 20),
                ["d2"] = new Driver("d2", 30, 40),
                ["d3"] = new Driver("d3", 50, 60),
                ["d4"] = new Driver("d4", 70, 80),
                ["d5"] = new Driver("d5", 90, 10),
                ["d6"] = new Driver("d6", 25, 35),
                ["d7"] = new Driver("d7", 45, 55),
                ["d8"] = new Driver("d8", 65, 75),
                ["d9"] = new Driver("d9", 85, 5),
                ["d10"] = new Driver("d10", 15, 25)
            };
        }

        protected double CalculateDistance(int x1, int y1, int x2, int y2)
        {
            int dx = x1 - x2;
            int dy = y1 - y2;
            return Math.Sqrt(dx * dx + dy * dy);
        }

        protected void AssertDriversOrderedByDistance(List<DriverDistance> results)
        {
            for (int i = 0; i < results.Count - 1; i++)
            {
                Assert.That(results[i].Distance, Is.LessThanOrEqualTo(results[i + 1].Distance));
            }
        }
    }
}