﻿using Practice.Models;
using Practice.Services;

namespace Practice.Benchmarks
{
    public class AlgorithmComparer
    {
        public class ComparisonResult
        {
            public string AlgorithmName { get; set; } = string.Empty;
            public double AverageTimeMs { get; set; }
            public long MemoryUsageBytes { get; set; }
            public double AccuracyPercent { get; set; }
            public int CorrectResults { get; set; }
            public int TotalComparisons { get; set; }
        }

        public static List<ComparisonResult> CompareAlgorithms(DriverSelectionService service, List<Order> testOrders, int iterations = 10)
        {
            var algorithms = service.GetAlgorithms();
            var results = new List<ComparisonResult>();

            var referenceResults = new List<List<DriverDistance>>();
            foreach (var order in testOrders)
            {
                referenceResults.Add(service.FindNearestDrivers(0, order));
            }

            for (int i = 0; i < algorithms.Count; i++)
            {
                var stopwatch = System.Diagnostics.Stopwatch.StartNew();
                long memoryBefore = GC.GetTotalMemory(true);

                for (int iter = 0; iter < iterations; iter++)
                {
                    foreach (var order in testOrders)
                    {
                        algorithms[i].FindNearestDrivers(order, 5);
                    }
                }

                stopwatch.Stop();
                long memoryAfter = GC.GetTotalMemory(true);
                GC.Collect();

                int correctResults = 0;
                int totalComparisons = 0;

                if (i > 0)
                {
                    for (int j = 0; j < testOrders.Count; j++)
                    {
                        var algorithmResult = algorithms[i].FindNearestDrivers(testOrders[j], 5);
                        var referenceResult = referenceResults[j];

                        for (int k = 0; k < algorithmResult.Count; k++)
                        {
                            if (algorithmResult[k].Driver.Id == referenceResult[k].Driver.Id)
                            {
                                correctResults++;
                            }
                            totalComparisons++;
                        }
                    }
                }
                else
                {
                    correctResults = totalComparisons;
                }

                results.Add(new ComparisonResult
                {
                    AlgorithmName = algorithms[i].AlgorithmName,
                    AverageTimeMs = stopwatch.Elapsed.TotalMilliseconds / (iterations * testOrders.Count),
                    MemoryUsageBytes = memoryAfter - memoryBefore,
                    AccuracyPercent = i == 0 ? 100 : (double)correctResults / totalComparisons * 100,
                    CorrectResults = correctResults,
                    TotalComparisons = totalComparisons
                });
            }

            return results;
        }
    }
}