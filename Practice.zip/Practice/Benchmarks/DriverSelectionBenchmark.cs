﻿using BenchmarkDotNet.Attributes;
using BenchmarkDotNet.Running;
using Practice.Models;
using Practice.Services;

namespace Practice.Benchmarks
{
    [MemoryDiagnoser]
    public class DriverSelectionBenchmark
    {
        private DriverSelectionService _service = null!;
        private List<Order> _testOrders = null!;
        private readonly Random _random = new Random(42);

        [Params(100, 1000, 5000)]
        public int DriverCount { get; set; }

        [GlobalSetup]
        public void Setup()
        {
            const int N = 1000;
            const int M = 1000;

            _service = new DriverSelectionService(N, M);
            _testOrders = new List<Order>();

            for (int i = 0; i < DriverCount; i++)
            {
                var driver = new Driver(
                    $"driver_{i}",
                    _random.Next(0, N),
                    _random.Next(0, M)
                );
                _service.AddOrUpdateDriver(driver);
            }

            for (int i = 0; i < 10; i++)
            {
                _testOrders.Add(new Order(
                    _random.Next(0, N),
                    _random.Next(0, M)
                ));
            }
        }

        [Benchmark]
        public void BruteForce()
        {
            foreach (var order in _testOrders)
            {
                _service.FindNearestDrivers(0, order);
            }
        }

        [Benchmark]
        public void GridPartition()
        {
            foreach (var order in _testOrders)
            {
                _service.FindNearestDrivers(1, order);
            }
        }

        [Benchmark]
        public void PriorityQueue()
        {
            foreach (var order in _testOrders)
            {
                _service.FindNearestDrivers(3, order);
            }
        }
    }
}