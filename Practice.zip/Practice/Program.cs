﻿using BenchmarkDotNet.Running;
using Practice.Benchmarks;
using Practice.Models;
using Practice.Services;

namespace Practice
{
    class Program
    {
        static void Main(string[] args)
        {
            if (args.Length > 0 && args[0] == "test")
            {
                TestFunctionality();
            }
            else if (args.Length > 0 && args[0] == "benchmark")
            {
                RunBenchmarks();
            }
            else if (args.Length > 0 && args[0] == "compare")
            {
                CompareAlgorithms();
            }
            else
            {
                ShowDemo();
            }
        }

        static void CompareAlgorithms()
        {


            var testScenarios = new[]
            {
                new { Name = "(100)", Count = 100 },
                new { Name = "(1000)", Count = 1000 },
                new { Name = "(5000)", Count = 5000 }
            };

            foreach (var scenario in testScenarios)
            {
                Console.WriteLine($"\n{scenario.Name}:");
                Console.WriteLine(new string('-', 50));

                CompareAlgorithmsForScenario(scenario.Count);
            }

            CompareAccuracy();
        }

        static void CompareAlgorithmsForScenario(int driverCount)
        {
            const int N = 1000;
            const int M = 1000;
            const int testOrdersCount = 100;
            var random = new Random(42);

            var service = new DriverSelectionService(N, M);

            for (int i = 0; i < driverCount; i++)
            {
                var driver = new Driver(
                    $"driver_{i}",
                    random.Next(0, N),
                    random.Next(0, M)
                );
                service.AddOrUpdateDriver(driver);
            }

            var testOrders = new List<Order>();
            for (int i = 0; i < testOrdersCount; i++)
            {
                testOrders.Add(new Order(
                    random.Next(0, N),
                    random.Next(0, M)
                ));
            }

            var algorithms = service.GetAlgorithms();
            var results = new List<AlgorithmResult>();

            foreach (var algorithm in algorithms)
            {
                var stopwatch = System.Diagnostics.Stopwatch.StartNew();
                long totalMemoryBefore = GC.GetTotalMemory(true);

                foreach (var order in testOrders)
                {
                    algorithm.FindNearestDrivers(order, 5);
                }

                stopwatch.Stop();
                long totalMemoryAfter = GC.GetTotalMemory(true);
                GC.Collect();

                results.Add(new AlgorithmResult
                {
                    Name = algorithm.AlgorithmName,
                    TimeMs = stopwatch.Elapsed.TotalMilliseconds,
                    MemoryBytes = totalMemoryAfter - totalMemoryBefore,
                    OperationsPerSecond = testOrdersCount / stopwatch.Elapsed.TotalSeconds
                });
            }

            results = results.OrderBy(r => r.TimeMs).ToList();

            Console.WriteLine($"{"Алгоритм",-20} {"Время (мс)",-12} {"Оп/сек",-12} {"Память (KB)",-12} {"Относит. скорость"}");
            Console.WriteLine(new string('-', 80));

            double bestTime = results[0].TimeMs;

            foreach (var result in results)
            {
                double relativeSpeed = bestTime / result.TimeMs;
                string speedIndicator = relativeSpeed >= 0.9 ? "✓" : relativeSpeed >= 0.5 ? "~" : "✗";

                Console.WriteLine($"{result.Name,-20} {result.TimeMs,-12:F2} {result.OperationsPerSecond,-12:F0} {result.MemoryBytes / 1024,-12:F1} {relativeSpeed,-8:F2}x {speedIndicator}");
            }
        }

        static void CompareAccuracy()
        {
            const int N = 1000;
            const int M = 1000;
            var random = new Random(42);

            var service = new DriverSelectionService(N, M);

            var drivers = new[]
            {
                new Driver("d1", 10, 20),
                new Driver("d2", 30, 40),
                new Driver("d3", 50, 60),
                new Driver("d4", 70, 80),
                new Driver("d5", 90, 10),
                new Driver("d6", 25, 35),
                new Driver("d7", 45, 55),
                new Driver("d8", 65, 75),
                new Driver("d9", 85, 5),
                new Driver("d10", 15, 25),
                new Driver("d11", 35, 45),
                new Driver("d12", 55, 65),
                new Driver("d13", 75, 85),
                new Driver("d14", 95, 15),
                new Driver("d15", 5, 95)
            };

            foreach (var driver in drivers)
            {
                service.AddOrUpdateDriver(driver);
            }

            var testOrders = new[]
            {
                new Order(40, 45),
                new Order(10, 10),
                new Order(90, 90),
                new Order(50, 50),
                new Order(25, 75)
            };

            var algorithms = service.GetAlgorithms();
            var bruteForceResults = new List<List<DriverDistance>>();

            foreach (var order in testOrders)
            {
                bruteForceResults.Add(service.FindNearestDrivers(0, order));
            }

            Console.WriteLine($"{"Алгоритм",-20} {"Точность",-12} {"Совпадений",-12} {"Средняя ошибка"}");
            Console.WriteLine(new string('-', 60));

            for (int i = 0; i < algorithms.Count; i++)
            {
                if (i == 0) continue;

                int totalMatches = 0;
                int totalComparisons = 0;
                double totalError = 0;

                for (int j = 0; j < testOrders.Length; j++)
                {
                    var algorithmResult = service.FindNearestDrivers(i, testOrders[j]);
                    var bruteForceResult = bruteForceResults[j];

                    int matches = 0;
                    for (int k = 0; k < algorithmResult.Count; k++)
                    {
                        if (algorithmResult[k].Driver.Id == bruteForceResult[k].Driver.Id)
                        {
                            matches++;
                        }
                        totalError += Math.Abs(algorithmResult[k].Distance - bruteForceResult[k].Distance);
                    }
                    totalMatches += matches;
                    totalComparisons += algorithmResult.Count;
                }

                double accuracy = (double)totalMatches / totalComparisons * 100;
                double avgError = totalError / totalComparisons;

                Console.WriteLine($"{algorithms[i].AlgorithmName,-20} {accuracy,-12:F1}% {totalMatches + "/" + totalComparisons,-12} {avgError,-10:F4}");
            }
        }

        static void RunBenchmarks()
        {
            Console.WriteLine("Запуск бенчмарков...");
            var summary = BenchmarkRunner.Run<DriverSelectionBenchmark>();
            Console.WriteLine("Бенчмарки завершены!");
        }

        static void TestFunctionality()
        {
            Console.WriteLine("Тестирование функциональности...");

            var service = new DriverSelectionService(100, 100);

            var drivers = new[]
            {
                new Driver("d1", 10, 20),
                new Driver("d2", 30, 40),
                new Driver("d3", 50, 60),
                new Driver("d4", 70, 80),
                new Driver("d5", 90, 10),
                new Driver("d6", 25, 35),
                new Driver("d7", 45, 55),
                new Driver("d8", 65, 75),
                new Driver("d9", 85, 5),
                new Driver("d10", 15, 25)
            };

            foreach (var driver in drivers)
            {
                service.AddOrUpdateDriver(driver);
            }

            var order = new Order(40, 45);

            var algorithms = service.GetAlgorithms();
            for (int i = 0; i < algorithms.Count; i++)
            {
                var result = service.FindNearestDrivers(i, order);
                Console.WriteLine($"\n{algorithms[i].AlgorithmName}:");
                foreach (var driverDist in result)
                {
                    Console.WriteLine($"  {driverDist.Driver.Id}: ({driverDist.Driver.X}, {driverDist.Driver.Y}) - {driverDist.Distance:F2}");
                }
            }
        }

        static void ShowDemo()
        {
            TestFunctionality();
        }
    }

    public class AlgorithmResult
    {
        public string Name { get; set; } = string.Empty;
        public double TimeMs { get; set; }
        public long MemoryBytes { get; set; }
        public double OperationsPerSecond { get; set; }
    }
}