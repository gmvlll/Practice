﻿using Practice.Models;
using Practice.Services;

namespace Practice.Algorithms
{
    public class BruteForceDriverService : IDriverService
    {
        private readonly Dictionary<string, Driver> _drivers;

        public string AlgorithmName => "Brute Force";

        public BruteForceDriverService(Dictionary<string, Driver> drivers)
        {
            _drivers = drivers;
        }

        public void AddOrUpdateDriver(Driver driver)
        {

        }

        public void RemoveDriver(string driverId)
        {
        
        }

        public List<DriverDistance> FindNearestDrivers(Order order, int count = 5)
        {
            var distances = new List<DriverDistance>();

            foreach (var driver in _drivers.Values)
            {
                double distance = CalculateDistance(driver.X, driver.Y, order.X, order.Y);
                distances.Add(new DriverDistance(driver, distance));
            }

            return distances
                .OrderBy(d => d.Distance)
                .Take(count)
                .ToList();
        }

        private double CalculateDistance(int x1, int y1, int x2, int y2)
        {
            int dx = x1 - x2;
            int dy = y1 - y2;
            return Math.Sqrt(dx * dx + dy * dy);
        }
    }
}