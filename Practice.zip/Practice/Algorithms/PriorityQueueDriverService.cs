﻿using Practice.Models;
using Practice.Services;

namespace Practice.Algorithms
{
    public class PriorityQueueDriverService : IDriverService
    {
        private readonly Dictionary<string, Driver> _drivers;

        public string AlgorithmName => "Priority Queue";

        public PriorityQueueDriverService(Dictionary<string, Driver> drivers)
        {
            _drivers = drivers;
        }

        public void AddOrUpdateDriver(Driver driver)
        {

        }

        public void RemoveDriver(string driverId)
        {

        }

        public List<DriverDistance> FindNearestDrivers(Order order, int count = 5)
        {

            var queue = new PriorityQueue<DriverDistance, double>();

            foreach (var driver in _drivers.Values)
            {
                double distance = CalculateDistance(driver.X, driver.Y, order.X, order.Y);
                queue.Enqueue(new DriverDistance(driver, distance), distance);
            }

            var result = new List<DriverDistance>();
            for (int i = 0; i < count && queue.Count > 0; i++)
            {
                result.Add(queue.Dequeue());
            }

            return result;
        }

        private double CalculateDistance(int x1, int y1, int x2, int y2)
        {
            int dx = x1 - x2;
            int dy = y1 - y2;
            return Math.Sqrt(dx * dx + dy * dy);
        }
    }
}