﻿using Practice.Models;
using Practice.Services;

namespace Practice.Algorithms
{
    public class GridPartitionDriverService : IDriverService
    {
        private readonly Dictionary<string, Driver> _drivers;
        private readonly List<Driver>[,] _grid;
        private readonly int _gridSizeX;
        private readonly int _gridSizeY;
        private readonly int _cellSize;

        public string AlgorithmName => "Grid Partition";

        public GridPartitionDriverService(Dictionary<string, Driver> drivers, int n, int m, int cellSize = 10)
        {
            _drivers = drivers;
            _cellSize = cellSize;
            _gridSizeX = (int)Math.Ceiling((double)n / cellSize);
            _gridSizeY = (int)Math.Ceiling((double)m / cellSize);
            _grid = new List<Driver>[_gridSizeX, _gridSizeY];

            for (int i = 0; i < _gridSizeX; i++)
                for (int j = 0; j < _gridSizeY; j++)
                    _grid[i, j] = new List<Driver>();

            foreach (var driver in drivers.Values)
            {
                AddDriverToGrid(driver);
            }
        }

        public void AddOrUpdateDriver(Driver driver)
        {
            RemoveDriver(driver.Id);
            AddDriverToGrid(driver);
        }

        public void RemoveDriver(string driverId)
        {
            if (_drivers.TryGetValue(driverId, out var driver))
            {
                var cell = GetGridCell(driver.X, driver.Y);
                _grid[cell.x, cell.y].RemoveAll(d => d.Id == driverId);
            }
        }

        public List<DriverDistance> FindNearestDrivers(Order order, int count = 5)
        {
            var orderCell = GetGridCell(order.X, order.Y);
            var candidates = new List<Driver>();

            int searchRadius = 1;
            while (candidates.Count < count * 3 && searchRadius <= Math.Max(_gridSizeX, _gridSizeY))
            {
                for (int dx = -searchRadius; dx <= searchRadius; dx++)
                {
                    for (int dy = -searchRadius; dy <= searchRadius; dy++)
                    {
                        if (Math.Abs(dx) != searchRadius && Math.Abs(dy) != searchRadius)
                            continue;

                        int x = orderCell.x + dx;
                        int y = orderCell.y + dy;

                        if (x >= 0 && x < _gridSizeX && y >= 0 && y < _gridSizeY)
                        {
                            candidates.AddRange(_grid[x, y]);
                        }
                    }
                }

                if (candidates.Count >= count) break;
                searchRadius++;
            }

            if (candidates.Count < count)
            {
                candidates.Clear();
                foreach (var cell in _grid)
                {
                    candidates.AddRange(cell);
                }
            }

            return candidates
                .Select(d => new DriverDistance(d, CalculateDistance(d.X, d.Y, order.X, order.Y)))
                .OrderBy(d => d.Distance)
                .Take(count)
                .ToList();
        }

        private void AddDriverToGrid(Driver driver)
        {
            var cell = GetGridCell(driver.X, driver.Y);
            _grid[cell.x, cell.y].Add(driver);
        }

        private (int x, int y) GetGridCell(int x, int y)
        {
            return (x / _cellSize, y / _cellSize);
        }

        private double CalculateDistance(int x1, int y1, int x2, int y2)
        {
            int dx = x1 - x2;
            int dy = y1 - y2;
            return Math.Sqrt(dx * dx + dy * dy);
        }
    }
}