﻿namespace Practice.Models
{
    public class Driver
    {
        public string Id { get; set; }
        public int X { get; set; }
        public int Y { get; set; }

        public Driver(string id, int x, int y)
        {
            Id = id;
            X = x;
            Y = y;
        }
    }

    public class Order
    {
        public int X { get; set; }
        public int Y { get; set; }

        public Order(int x, int y)
        {
            X = x;
            Y = y;
        }
    }

    public class DriverDistance
    {
        public Driver Driver { get; set; }
        public double Distance { get; set; }

        public DriverDistance(Driver driver, double distance)
        {
            Driver = driver;
            Distance = distance;
        }
    }
}